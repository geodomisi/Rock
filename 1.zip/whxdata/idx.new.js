(function() {
var index =  {"type":"index","chunkinfos":[{"type":"chunkinfo","first":"","last":"","num":"0","node":"idata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
