(function() {
var glossary =  {"type":"data","entrys":[]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), glossary, { sync:true });
})();
